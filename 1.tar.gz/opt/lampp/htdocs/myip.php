<?php
function getClientIP() {
    $ip = $_SERVER['HTTP_CF_CONNECTING_IP'] ?: $_SERVER['HTTP_CLIENT_IP'] ?: $_SERVER['HTTP_X_FORWARDED_FOR'] ?: $_SERVER['REMOTE_ADDR'];

    // Remove any potential comma and extra white spaces
    $ip = preg_replace('/\s*,\s*/', '', $ip);

    // Validate the IP address
    if (filter_var($ip, FILTER_VALIDATE_IP)) {
        return $ip;
    }

    // Return a default IP address (optional)
    return '0.0.0.0';
}

// 使用该函数获取客户端IP地址
$clientIP = getClientIP();
echo $clientIP;


?>
